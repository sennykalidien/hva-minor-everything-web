app.config(function($sceDelegateProvider) {

    $sceDelegateProvider.resourceUrlWhitelist([
        'self',
        '**'
    ]);

});
