//(function () {
//    //Here your view content is fully loaded !!
//    var _videoButton = document.querySelector('.bln-homeheader .buttons .playbutton');
//    var _videoIframe = document.querySelector('.bln-iframewrapper-video figure');
//
//    console.log(_videoButton);
//    console.log(_videoIframe);
//
//    _videoButton.addEventListener('click', videoClicked, false);
//
//    function videoClicked() {
//        _videoIframe.style.display = "block";
//    }
//    videoClicked();
//}());

