// Bundlin Environment Variable
// please note, this file is overwritten during deployment
// possible values: staging, acceptance, production
var BLN_ENVIRONMENT = "development";
var BLN_BUILD_TIMESTAMP = "111111111";