// task: autoprefixer
module.exports = {

    // targets
    styles_project: {
        src: '.grunt-tmp/css/app.css',
        dest: '.grunt-tmp/css/app.css'
    },
    styles_critical: {
        src: '.grunt-tmp/css/critical.css',
        dest: '.grunt-tmp/css/critical.css'
    }
};
