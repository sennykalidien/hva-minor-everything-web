module.exports = {
    custom: {
        options: {
            url: 'src/statics/critical.html',
            width: 1200,
            height: 900,
            filename: '.grunt-tmp/css/app.css',
            outputfile: '.grunt-tmp/css/critical.css'
        }
    }
};