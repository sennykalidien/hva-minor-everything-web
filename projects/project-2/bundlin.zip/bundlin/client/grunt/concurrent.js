// task: concurrent
module.exports = {

    // targets
    tasks: [ 'watch' ],
    options: {
        logConcurrentOutput: true
    }

};
