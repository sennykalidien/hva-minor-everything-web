// task: sass
module.exports = {

    // targets
    styles_project: {
        options: {
            
        },
        files: {
            '.grunt-tmp/css/app.css': 'src/styles/imports.less'
        }
    }

};
