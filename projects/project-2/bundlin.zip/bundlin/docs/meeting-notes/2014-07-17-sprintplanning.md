## Gebruikers (overleggen)
- Write/read access (ACL)
- Wat te doen met bundles als een gebruiker zijn account verwijderd?

## Authorisatie
- User access to Beta
- Bundle author can only get bundle if it is unpublished

## Bundles
- Save ids to tweeted messages

## Bundle items
- Reorder endpoint only post ids, order is calculated on the backend (security)


## Progress bar
- Awesomeness onzichtbaar tot de bundel valid is (100% voldoet aan minimale eisen)
