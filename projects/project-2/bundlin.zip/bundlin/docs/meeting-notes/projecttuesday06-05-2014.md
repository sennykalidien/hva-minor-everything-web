projecttuesday 06-05-2014

aanwezigen
pim, peter, bryan, jesse

agenda 
* technologiekeuze bundlin
* ruwe architectuur schets bundlin
* kickstart voor frontenddevelopment

# Technologiekeuze bundlin

## Backend opties 
### NodeJS
#### valkuilen nodejs
* minder proven technology
* minder ervaren developers
* hype

### PHP
#### valkuilen php
* minder performance
* minder developsnelheid
* minder schaalbaar
### Java (play / spring)
### Go
### Python (flex)

## Frontend
* AngularJS
* less / sass
* grunt / gulp

## Queues
RabbitMQ
Elasticbeanstalk?

## Infrastructuur opties
* eigen vps
* amazon cloud services / ec2 instances
* elastic beanstalk

## (voorlopige) Keuze
* NodeJS + Express
* Mongodb
* RabbitMQ
* AngularJS
* less
* grunt

# sidenote: animaties
* focussen op css transities
* requirements
    * moet goed performen
        * aanvoelen als webapp
            * fancy

# sidenote: preliminary roadmap

## V1 private beta
* publiek bundle weergeven
* intern bundle maken
* fallbacks voor interactie

## V2 public beta
* bundles aanmaken publiek
* beperkte groep gebruikers (100)

## V3 public
* signup open zetten naar buitenwereld

# actiepunten:
* Pim: gesprek met true (jean paul) regelen
