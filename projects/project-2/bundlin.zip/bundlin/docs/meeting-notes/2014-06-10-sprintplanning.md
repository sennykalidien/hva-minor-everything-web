# Bundlin sprint 2 meeting 10-06-2014

# Decisions

* Templates

    * "templates" hardcoded to html css javascript, items get validated on front and backend

* Bundle Entity

    * bundle document contains items and draft items and has published status

* Item Entity

    * should have changeable order

* Environment variables

    * environment variables should not contain release dependent variables to ensure proper rollbacks.
