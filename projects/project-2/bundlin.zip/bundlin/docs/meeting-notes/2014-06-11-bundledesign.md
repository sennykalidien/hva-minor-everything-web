# Final design

```
[
    {
        "id",
        "title",
        "description",
        "picture",
        "tags",
        "created_at",
        "updated_at",
        "author",
        "items": [
            {
                "title",
                "description",
                "picture",
                "comment",
                "url",
                "type": "article",
                "created_at",
                "updated_at",
            },
            {
                "quote",
                "quote_author",
                "url",
                "type": "quote",
                "created_at",
                "updated_at",
            },
            {
                "media_id",
                "media_origin": "vimeo|youtube|googlemaps",
                "comment",
                "url",
                "type": "media",
                "created_at",
                "updated_at",
            },
        ]
    }
]
```
